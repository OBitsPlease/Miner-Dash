Epic Cash official CPU miner 2.3.2

Source:
https://github.com/EpicCash/epic-miner
commit 9e33237186e380480a982f57fbab6c1ab3743724

The launcher generates the official miner's TOML configuration and then execs
the locally built mining executable. The RandomX lifecycle includes a local
fix that starts hashing as soon as its asynchronously generated dataset is
ready, without waiting for another Stratum job. Supported launcher arguments:

  --stratum [stratum+tcp|stratum+ssl|stratum+tls]://HOST:PORT
  --threads N
  --large-pages
  --no-large-pages

When `--threads` is omitted, the launcher uses all logical CPU cores reported
by `nproc`, clamped to the miner's 255-thread limit.

RandomX is statically linked. The package does not include a developer fee,
wallet, pool redirection, or credentials.
